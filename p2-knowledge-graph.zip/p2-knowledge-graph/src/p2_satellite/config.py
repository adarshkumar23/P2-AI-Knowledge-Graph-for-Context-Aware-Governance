"""
Central configuration for the P2 satellite.
Loaded once, imported everywhere. No config values scattered across files.
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


def _env(key: str, default: str | None = None, required: bool = False) -> str:
    val = os.getenv(key, default)
    if required and not val:
        raise RuntimeError(f"Missing required env var: {key}")
    return val


@dataclass(frozen=True)
class Settings:
    core_base_url: str
    core_export_api_key: str
    core_ingest_api_key: str
    safety_net_poll_hours: float
    event_listener_host: str
    event_listener_port: int
    event_listener_shared_secret: str
    max_traversal_depth: int
    embedding_model: str
    embedding_dim: int
    methodology_version: str


def load_settings() -> Settings:
    return Settings(
        core_base_url=_env("CORE_BASE_URL", "http://localhost:8000"),
        core_export_api_key=_env("CORE_EXPORT_API_KEY", "dev-export-key"),
        core_ingest_api_key=_env("CORE_INGEST_API_KEY", "dev-ingest-key"),
        safety_net_poll_hours=float(_env("SAFETY_NET_POLL_HOURS", "2")),
        event_listener_host=_env("EVENT_LISTENER_HOST", "0.0.0.0"),
        event_listener_port=int(_env("EVENT_LISTENER_PORT", "8501")),
        event_listener_shared_secret=_env("EVENT_LISTENER_SHARED_SECRET", "dev-secret"),
        max_traversal_depth=int(_env("MAX_TRAVERSAL_DEPTH", "6")),
        embedding_model=_env("EMBEDDING_MODEL", "all-MiniLM-L6-v2"),
        embedding_dim=int(_env("EMBEDDING_DIM", "384")),
        methodology_version=_env("METHODOLOGY_VERSION", "p2-v1.0.0"),
    )


settings = load_settings()
